Azure Hotel – Responsive Bootstrap 5 Hotel Website Template
Version: 1.0.0
Author: Haseeb Zaheer

------------------------------------------------------
📌 DESCRIPTION
------------------------------------------------------
Azure Hotel is a modern and responsive hotel website template built with HTML5, CSS3, Bootstrap 5, and JavaScript. 
It includes all essential pages like Homepage, Rooms, Booking, Gallery, and Contact.

------------------------------------------------------
📂 FILE STRUCTURE
------------------------------------------------------
azure-hotel/
 ├── Documentation/       → Setup & customization guide
 ├── HTML/                → Main template files
 │     ├── index.html
 │     ├── rooms.html
 │     ├── booking.html
 │     ├── contact.html
 │     └── assets/
 │           ├── css/
 │           ├── js/
 │           ├── images/
 │           └── fonts/ (if used)
 └── README.txt

------------------------------------------------------
⚙️ REQUIREMENTS
------------------------------------------------------
- A modern browser (Chrome, Firefox, Safari, Edge)
- Basic knowledge of HTML & CSS for customization
- Text editor (VS Code, Sublime Text, etc.)

------------------------------------------------------
📖 DOCUMENTATION
------------------------------------------------------
Please open the file inside the "Documentation" folder for full instructions on:
- Installation
- Customization
- File structure
- Credits

------------------------------------------------------
📧 SUPPORT
------------------------------------------------------
If you have purchased support, please reach out via ThemeForest profile contact.

------------------------------------------------------
✅ CREDITS
------------------------------------------------------
- Bootstrap 5 (https://getbootstrap.com/)
- Bootstrap Icons (https://icons.getbootstrap.com/)
- Google Fonts (Poppins, Merriweather – https://fonts.google.com/)
- Images: Unsplash / Pexels (Demo purposes only – replace with your own licensed images)
