// Azure Hotel - Main JS

document.addEventListener('DOMContentLoaded', () => {
  setCurrentYear();
  initSmoothScroll();
  initScrollReveal();
  initMobileNavAutoClose();
  initRoomFilter();
  initBookingForm();
  initContactForm();
  preselectRoomFromQuery();
  initImageFallback();
});

function setCurrentYear() {
  const yearEl = document.getElementById('year');
  if (yearEl) yearEl.textContent = new Date().getFullYear();
}

// Smooth scrolling for in-page anchors
function initSmoothScroll() {
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', event => {
      const targetId = anchor.getAttribute('href');
      if (!targetId || targetId === '#' || targetId.startsWith('#!')) return;
      const targetEl = document.querySelector(targetId);
      if (targetEl) {
        event.preventDefault();
        targetEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
  });
}

// Reveal on scroll using IntersectionObserver
function initScrollReveal() {
  const revealEls = document.querySelectorAll('.reveal');
  if (!('IntersectionObserver' in window) || revealEls.length === 0) return;
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('reveal-visible');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.15 });
  revealEls.forEach(el => observer.observe(el));
}

// Close mobile nav when clicking a link
function initMobileNavAutoClose() {
  const navbar = document.getElementById('mainNavbar');
  if (!navbar) return;
  navbar.querySelectorAll('a.nav-link').forEach(link => {
    link.addEventListener('click', () => {
      const bsCollapse = bootstrap.Collapse.getInstance(navbar);
      if (bsCollapse) bsCollapse.hide();
    });
  });
}

// Rooms filter
function initRoomFilter() {
  const filterButtons = document.querySelectorAll('[data-filter]');
  const roomCards = document.querySelectorAll('.room-card');
  if (filterButtons.length === 0 || roomCards.length === 0) return;

  filterButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      filterButtons.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const filter = btn.getAttribute('data-filter');
      roomCards.forEach(card => {
        const category = card.getAttribute('data-category');
        const show = filter === 'all' || category === filter;
        card.style.display = show ? '' : 'none';
      });
    });
  });
}

// Booking form validation and modal
function initBookingForm() {
  const form = document.getElementById('bookingForm');
  if (!form) return;

  form.addEventListener('submit', event => {
    event.preventDefault();
    event.stopPropagation();

    const name = document.getElementById('guestName');
    const email = document.getElementById('email');
    const phone = document.getElementById('phone');
    const checkIn = document.getElementById('checkIn');
    const checkOut = document.getElementById('checkOut');
    const roomType = document.getElementById('roomType');
    const guests = document.getElementById('guests');

    const emailValid = /.+@.+\..+/.test(email.value.trim());
    toggleValidity(email, emailValid);

    const datesValid = validateDates(checkIn, checkOut);
    const guestsValid = Number(guests.value) >= 1 && Number(guests.value) <= 8;

    const requiredInputs = [name, phone, roomType];
    requiredInputs.forEach(input => toggleValidity(input, Boolean(input.value)));
    toggleValidity(guests, guestsValid);

    const allValid = [name, email, phone, checkIn, checkOut, roomType, guests].every(isValidField);
    if (!allValid) return;

    // Populate modal summary
    document.getElementById('summaryName').textContent = name.value.trim();
    document.getElementById('summaryRoom').textContent = roomType.value;
    document.getElementById('summaryGuests').textContent = guests.value;
    document.getElementById('summaryDates').textContent = `${checkIn.value} → ${checkOut.value}`;

    const modalEl = document.getElementById('bookingModal');
    const modal = new bootstrap.Modal(modalEl);
    modal.show();

    modalEl.addEventListener('hidden.bs.modal', () => {
      form.reset();
      clearValidation(form);
    }, { once: true });
  });
}

function validateDates(checkIn, checkOut) {
  const inDate = new Date(checkIn.value);
  const outDate = new Date(checkOut.value);
  const today = new Date();
  today.setHours(0,0,0,0);
  const valid = Boolean(checkIn.value) && Boolean(checkOut.value) && inDate >= today && outDate > inDate;
  toggleValidity(checkIn, Boolean(checkIn.value) && inDate >= today);
  toggleValidity(checkOut, Boolean(checkOut.value) && outDate > inDate);
  return valid;
}

function isValidField(field) {
  return field.classList.contains('is-valid') || (!field.classList.contains('is-invalid') && field.checkValidity());
}

function toggleValidity(el, condition) {
  el.classList.toggle('is-invalid', !condition);
  el.classList.toggle('is-valid', condition);
}

function clearValidation(form) {
  form.querySelectorAll('.is-valid, .is-invalid').forEach(el => {
    el.classList.remove('is-valid', 'is-invalid');
  });
}

// Contact form validation
function initContactForm() {
  const form = document.getElementById('contactForm');
  if (!form) return;
  const name = document.getElementById('contactName');
  const email = document.getElementById('contactEmail');
  const subject = document.getElementById('contactSubject');
  const message = document.getElementById('contactMessage');

  form.addEventListener('submit', event => {
    event.preventDefault();
    event.stopPropagation();
    const emailValid = /.+@.+\..+/.test(email.value.trim());
    toggleValidity(email, emailValid);
    [name, subject, message].forEach(input => toggleValidity(input, Boolean(input.value.trim())));
    const allValid = [name, email, subject, message].every(isValidField);
    if (!allValid) return;
    // Simple success feedback
    const submitBtn = form.querySelector('button[type="submit"]');
    const original = submitBtn.innerHTML;
    submitBtn.innerHTML = '<i class="bi bi-check2-circle me-2"></i>Message Sent';
    submitBtn.classList.replace('btn-primary', 'btn-success');
    setTimeout(() => {
      form.reset();
      clearValidation(form);
      submitBtn.innerHTML = original;
      submitBtn.classList.replace('btn-success', 'btn-primary');
    }, 1500);
  });
}

// Preselect room type on booking page via query string (?room=)
function preselectRoomFromQuery() {
  const params = new URLSearchParams(window.location.search);
  const preselect = params.get('room');
  if (!preselect) return;
  const roomTypeSelect = document.getElementById('roomType');
  if (!roomTypeSelect) return;
  for (const option of roomTypeSelect.options) {
    if (option.text.toLowerCase() === decodeURIComponent(preselect).toLowerCase()) {
      option.selected = true;
      break;
    }
  }
}

// Global image fallback to local placeholder when remote images fail
function initImageFallback() {
  const placeholderSrc = 'assets/images/placeholder.svg';
  window.addEventListener('error', event => {
    const target = event.target;
    if (target && target.tagName === 'IMG' && !target.dataset.fallbackApplied) {
      target.dataset.fallbackApplied = 'true';
      target.src = placeholderSrc;
    }
  }, true);
}


